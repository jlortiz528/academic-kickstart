close all; clear all; clc;
replication_root      = pwd;
figure_folder         = fullfile(replication_root,'tables_and_figures');
function_folder       = fullfile(replication_root,'model','functions');
processed_data_folder = fullfile(replication_root,'model','processed_data');

addpath(function_folder);
addpath(figure_folder);
addpath(processed_data_folder);


%% --  Tables & figures from main text 

% Figure 1
run empirics/code/Figure1.m

% Figure A1
run empirics/code/FigureA1.m

% Figure A2, A3, A4, and A5
run empirics/code/FigureA2_FigureA3_FigureA4_FigureA5.m
